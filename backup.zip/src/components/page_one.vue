<template>
    <div style="width: 60vw; margin: 0 auto; padding: 0; box-sizing: border-box;">

        Page One
        <b-button variant="primary">Click me</b-button>
        <nav>
        <RouterLink to="/page_two">page_two</RouterLink>
       
      </nav>


    </div>
</template>

<script setup>


</script>