<template>
    <footer class="l-footer">
      <div class="footer-top">
        <div class="footer-top__inner">
          <div class="footer-top__phone">
            Contact Us <a
              class="footer-top__phone-link"
              href="tel:18437929300"
            >843-792-9300</a>
          </div>
          <nav
            class="social"
            role="navigation"
            aria-label="Social Media Links"
          >
            <ul class="social__list">
              <li class="social__item">
                <a
                  href="https://www.facebook.com/MUSCHollings"
                  class="social__link social__link--facebook"
                >
                  <svg class="icon icon-facebook"><use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-facebook" /></svg>
                </a> 
              </li>
              <li class="social__item">
                <a
                  href="https://twitter.com/muschollings"
                  class="social__link social__link--twitter"
                >
                  <svg class="icon icon-twitter"><use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-twitter" /></svg> 
                </a>
              </li>
              <li class="social__item">
                <a
                  href="https://www.instagram.com/hollingscancercenter"
                  class="social__link social__link--instagram"
                >Instagram</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      <div class="footer-middle">
        <nav
          class="footer-middle__inner"
          role="navigation"
          aria-label="Footer Primary Navigation"
        >
          <div class="footer-middle__column">
            <h3 class="footer-middle__title">
              About Hollings
            </h3>
            <ul class="footer-middle__links">
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/about"
                  class="footer-middle__link"
                  title=""
                >About Us</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/about/leadership"
                  class="footer-middle__link"
                  title=""
                >Leadership</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/about/contact-us"
                  class="footer-middle__link"
                  title=""
                >Contact Us</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/giving"
                  class="footer-middle__link"
                  title=""
                >Giving to Hollings</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/about/events"
                  class="footer-middle__link"
                  title=""
                >Events</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/news"
                  class="footer-middle__link"
                  title=""
                >Newsroom</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/news/patient-stories"
                  class="footer-middle__link"
                  title=""
                >Patient Stories</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/news/hollings-horizons"
                  class="footer-middle__link"
                  title=""
                >Magazine</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/news/subscribe"
                  class="footer-middle__link"
                  title=""
                >Subscribe to Newsletter</a>
              </li>
            </ul>
          </div>
          <div class="footer-middle__column">
            <h3 class="footer-middle__title">
              Patient Care
            </h3>
            <ul class="footer-middle__links">
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/MUSCApps/ProviderDirectory/hccProviders.aspx"
                  class="footer-middle__link"
                  title=""
                >Find a Provider</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/become-a-patient"
                  class="footer-middle__link"
                  title=""
                >Become a Patient</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/become-a-patient"
                  class="footer-middle__link"
                  title=""
                >Schedule an Appointment</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/clinical-trials"
                  class="footer-middle__link"
                  title=""
                >Clinical Trials</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/cancer-types"
                  class="footer-middle__link"
                  title=""
                >Cancer Types</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/cancer-treatment"
                  class="footer-middle__link"
                  title=""
                >Cancer Treatments</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/patient-resources"
                  class="footer-middle__link"
                  title=""
                >Patient Resources</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/become-a-patient/locations-and-parking"
                  class="footer-middle__link"
                  title=""
                >Locations &amp; Parking</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/health-professionals/refer"
                  class="footer-middle__link"
                  title=""
                >Refer a Patient</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/patients-visitors/billing"
                  class="footer-middle__link"
                  title=""
                >Patient Billing</a>
              </li>
            </ul>
          </div>
          <div class="footer-middle__column">
            <h3 class="footer-middle__title">
              Research
            </h3>
            <ul class="footer-middle__links">
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/programs"
                  class="footer-middle__link"
                  title=""
                >Research Programs</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/shared-resources"
                  class="footer-middle__link"
                  title=""
                >Shared Resources</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/clinical-trials/clinical-trials-office"
                  class="footer-middle__link"
                  title=""
                >Clinical Trials Office</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/funding"
                  class="footer-middle__link"
                  title=""
                >Funding Opportunities</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/education"
                  class="footer-middle__link"
                  title=""
                >Education and Training</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/research/membership"
                  class="footer-middle__link"
                  title=""
                >Membership</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="http://admin.hcc.musc.edu/profiles.aspx"
                  class="footer-middle__link"
                  title=""
                >Find a Researcher</a>
              </li>
            </ul>
          </div>
          <div class="footer-middle__column">
            <h3 class="footer-middle__title">
              Hollings Outreach
            </h3>
            <ul class="footer-middle__links">
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach"
                  class="footer-middle__link"
                  title=""
                >Outreach &amp; Engagement</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/cancer-health-disparities"
                  class="footer-middle__link"
                  title=""
                >Cancer Health Disparities</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/hpv"
                  class="footer-middle__link"
                  title=""
                >HPV Vaccination</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/smoking-cessation"
                  class="footer-middle__link"
                  title=""
                >Smoking Cessation</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/mobile-health-unit"
                  class="footer-middle__link"
                  title=""
                >Mobile Health Unit</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://muschealth.org/medical-services/cancer/prevention"
                  class="footer-middle__link"
                  title=""
                >Prevention &amp; Screenings</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/statewide-commitments"
                  class="footer-middle__link"
                  title=""
                >Statewide Commitments</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/outreach/education-awareness"
                  class="footer-middle__link"
                  title=""
                >Education &amp; Awareness</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://hollingscancercenter.musc.edu/patient-care/survivors"
                  class="footer-middle__link"
                  title=""
                >Survivorship</a>
              </li>
            </ul>
          </div>
          <div class="footer-middle__column">
            <h3 class="footer-middle__title">
              About MUSC
            </h3>
            <ul class="footer-middle__links">
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/human-resources"
                  class="footer-middle__link"
                  title=""
                >Careers</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/about/contact"
                  class="footer-middle__link"
                  title=""
                >Contact Us</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/about/staff-directory"
                  class="footer-middle__link"
                  title=""
                >Find a Person</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://giving.musc.edu/"
                  class="footer-middle__link"
                  title=""
                >Giving</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/about/a-to-z"
                  class="footer-middle__link"
                  title=""
                >MUSC A to Z</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/about/leadership/institutional-offices/communications/pamr"
                  class="footer-middle__link"
                  title=""
                >Public Affairs &amp; Media Relations</a>
              </li>
              <li class="footer-middle__item">
                <a
                  href="https://web.musc.edu/resources/health-and-wellness/wellness-center"
                  class="footer-middle__link"
                  title=""
                >Wellness Center</a>
              </li>
            </ul>
          </div>
          <a
            href="#"
            class="footer-middle__top-link js-backtotop"
          >
            <span class="show-for-sr">Jump back to top of page</span>
                <svg class="icon icon-circle-arrow-w"><use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-circle-arrow-w" /></svg> 
          </a>
        </nav>
      </div>
      <div class="footer-ctas">
        <div class="quick-links ">
          <a
            class="quick-link module"
            href="https://muschealth.org/patients-visitors/about-us/confidential-hotline"
            target=""
          >
            <svg class="icon icon-phone">
              <use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-phone" />
            </svg> 
            <div class="quick-link__title">Confidential Hotline</div>
          </a>
          <a
            class="quick-link module"
            href="https://muschealth.org/patients-visitors/contact/liaison"
            target=""
          >
             <svg class="icon icon-contact">
              <use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-contact" />
            </svg> 
            <div class="quick-link__title">Patient Complaint or Concern</div>
          </a>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="footer-bottom__inner">
          <span class="footer-bottom__logo right">
            <svg class="icon icon-nci-logo-footer"><use xlink:href="/img/musc-svg-sprite.c668351e.svg#icon-nci-logo-footer" /></svg> 
          </span>
          <div
            class="footer-bottom__upper"
            role="contentinfo"
          >
            <span class="footer-bottom__copyright">© Medical University of South Carolina</span>
            <address class="footer-bottom__address">
              86 Jonathan Lucas St, MSC 955, Charleston, SC 29425
            </address>
          </div>
          <div class="footer-bottom__lower">
            <ul
              class="footer-bottom__links"
              role="navigation"
              aria-label="Footer Secondary Navigation"
            >
              <li class="footer-bottom__item">
                <a
                  href="https://web.musc.edu/about/compliance/disclaimer"
                  class="footer-bottom__link"
                >Disclaimer</a>
              </li>
              <li class="footer-bottom__item">
                <a
                  href="https://web.musc.edu/about/compliance/privacy"
                  class="footer-bottom__link"
                >Privacy Policy</a>
              </li>
              <li class="footer-bottom__item">
                <a
                  href="https://web.musc.edu/about/compliance/accessibility"
                  class="footer-bottom__link"
                >Web Accessibility Statement</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  </template>
  
  <script>
    export default {
      name: 'FooterComponent'
    }
  </script>
  <style scoped>
  @import '../css/hollings_new.css';
  </style>
  
  