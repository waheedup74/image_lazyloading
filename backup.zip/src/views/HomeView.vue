<script setup>
// import TheWelcome from '../components/TheWelcome.vue'
import page_one from '../components/page_three.vue'
</script>

<template>
  <main>
    <page_one />
  </main>
</template>
